-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2022 at 07:40 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `miniproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `bc`
--

CREATE TABLE `bc` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `2022-12-19` int(5) DEFAULT NULL,
  `2022-12-20` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bc`
--

INSERT INTO `bc` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `2022-12-19`, `2022-12-20`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 1, 1),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 1, 1),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 1, 1),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 1, 1),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 1, 1),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 1, 1),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 1, 1),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 1, 1),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 1, 1),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 1, 1),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 1, 1),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 1, 1),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 1, 1),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 1, 1),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 0, 1),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 1, 0),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 1, 1),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 1, 1),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 0, 1),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 1, 1),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 1, 1),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 1, 0),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 1, 1),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 0, 1),
(25, 'DIPAK ', 'BAPU', 'MALI ', 1, 1),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 1, 1),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 1, 1),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 1, 1),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 1, 1),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 0, 1),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 1, 1),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 1, 1),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 1, 1),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 1, 1),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 0, 1),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 1, 1),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 1, 1),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 1, 1),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 1, 1),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 0, 1),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 1, 1),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 1, 1),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 1, 1),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 1, 1),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 1, 0),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 1, 1),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 1, 1),
(48, 'SHUBHAM ', 'KISHOR', 'ARAGADE', 1, 1),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 1, 1),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 1, 0),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 1, 1),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 1, 1),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 1, 1),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 1, 0),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 0, 1),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 1, 1),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 1, 1),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 1, 1),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 1, 1),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 1, 1),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 1, 1),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bc_marks`
--

CREATE TABLE `bc_marks` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `ca1` int(5) DEFAULT NULL,
  `midsem` int(5) DEFAULT NULL,
  `ca2` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bc_marks`
--

INSERT INTO `bc_marks` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `ca1`, `midsem`, `ca2`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 17, 15, 15),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 15, 12, 16),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 13, 13, 12),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 12, 16, 13),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 14, 14, 14),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 11, 19, 15),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 17, 18, 16),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 15, 17, 12),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 14, 15, 18),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 13, 12, 19),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 12, 16, 17),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 11, 13, 18),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 9, 15, 19),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 12, 14, 15),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 15, 18, 16),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 17, 17, 14),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 16, 19, 18),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 20, 20, 20),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 15, 15, 14),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 20, 20, 20),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 17, 18, 19),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 17, 18, 19),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 17, 18, 19),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 17, 18, 19),
(25, 'DIPAK ', 'BAPU', 'MALI ', 17, 18, 19),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 17, 18, 19),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 17, 18, 19),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 17, 18, 19),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 17, 18, 19),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 17, 18, 19),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 17, 18, 19),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 17, 18, 19),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 17, 18, 19),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 17, 18, 19),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 17, 18, 19),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 17, 18, 19),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 17, 18, 19),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 17, 18, 19),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 17, 18, 19),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 17, 18, 19),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 17, 18, 19),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 17, 18, 19),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 17, 18, 19),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 17, 18, 19),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 17, 18, 19),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 17, 18, 19),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 17, 18, 19),
(48, 'SHUBHAM ', 'KISHOR', 'ARAGADE', 17, 18, 19),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 17, 18, 19),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 17, 18, 19),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 17, 18, 19),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 17, 18, 19),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 17, 18, 19),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 17, 18, 19),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 17, 18, 19),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 17, 18, 19),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 17, 18, 19),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 17, 18, 19),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 17, 18, 19),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 17, 18, 19),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 17, 18, 19),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 17, 18, 19);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `sno` int(4) DEFAULT NULL,
  `name` text NOT NULL,
  `email` varchar(22) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `other` text NOT NULL,
  `dt` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`sno`, `name`, `email`, `phone`, `other`, `dt`) VALUES
(NULL, 'Harshal Ravindra Patil', 'harshalrp25@gmail.com', '09579107661', 'bknfwfbwf', '2022-11-27'),
(NULL, 'mkkm', 'nnkjmmkimk@hj.com', 'klmkjn', 'jkk', '2022-11-27');

-- --------------------------------------------------------

--
-- Table structure for table `dbs`
--

CREATE TABLE `dbs` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `2022-12-20` int(5) DEFAULT NULL,
  `2022-12-19` int(5) DEFAULT NULL,
  `2022-12-22` int(5) DEFAULT NULL,
  `2022-12-17` int(5) DEFAULT NULL,
  `2022-12-21` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dbs`
--

INSERT INTO `dbs` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `2022-12-20`, `2022-12-19`, `2022-12-22`, `2022-12-17`, `2022-12-21`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 1, 1, 1, 1, 1),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 1, 1, 1, 1, 1),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 1, 1, 1, 1, 1),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 1, 1, 1, 1, 1),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 1, 1, 1, 1, 1),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 1, 1, 1, 1, 1),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 1, 1, 1, 1, 1),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 1, 1, 1, 1, 1),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 1, 1, 1, 1, 1),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 1, 1, 1, 1, 1),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 1, 1, 1, 1, 1),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 1, 1, 1, 1, 1),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 1, 1, 1, 1, 1),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 1, 1, 1, 1, 1),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 1, 0, 1, 0, 1),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 1, 1, 1, 1, 0),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 1, 1, 1, 1, 1),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 1, 1, 1, 1, 1),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 1, 1, 1, 1, 1),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 1, 1, 1, 0, 1),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 1, 1, 1, 1, 1),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 1, 1, 1, 1, 0),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 1, 1, 1, 1, 1),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 1, 0, 1, 1, 1),
(25, 'DIPAK ', 'BAPU', 'MALI ', 1, 1, 1, 1, 1),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 1, 1, 1, 0, 1),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 1, 1, 1, 1, 1),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 1, 1, 1, 0, 1),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 1, 1, 1, 1, 1),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 1, 1, 1, 1, 1),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 1, 1, 1, 1, 1),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 1, 1, 1, 1, 1),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 1, 1, 1, 1, 1),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 1, 1, 1, 1, 1),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 1, 1, 1, 1, 1),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 1, 1, 1, 1, 1),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 1, 1, 1, 1, 1),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 1, 1, 1, 1, 1),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 1, 1, 1, 1, 1),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 1, 1, 1, 1, 1),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 1, 1, 1, 1, 1),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 1, 1, 1, 1, 1),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 1, 1, 1, 1, 1),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 1, 1, 1, 1, 1),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 1, 1, 1, 1, 0),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 1, 1, 1, 1, 1),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 1, 1, 1, 1, 1),
(48, 'SHUBHAM ', 'KISHOR', 'ARAGADE', 1, 1, 1, 1, 1),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 1, 1, 1, 1, 1),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 1, 1, 1, 1, 1),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 1, 1, 1, 1, 1),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 1, 1, 1, 1, 1),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 1, 1, 1, 1, 1),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 1, 1, 1, 1, 1),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 1, 1, 1, 1, 0),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 1, 1, 1, 1, 1),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 1, 1, 1, 1, 1),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 1, 1, 1, 1, 1),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 1, 1, 1, 1, 1),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 1, 1, 1, 1, 1),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 1, 1, 1, 1, 1),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dbs_marks`
--

CREATE TABLE `dbs_marks` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `ca1` int(5) DEFAULT NULL,
  `midsem` int(5) DEFAULT NULL,
  `ca2` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dbs_marks`
--

INSERT INTO `dbs_marks` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `ca1`, `midsem`, `ca2`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 15, 17, 11),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 16, 16, 13),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 12, 13, 17),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 15, 12, 12),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 14, 15, 14),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 17, 18, 16),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 0, 13, 15),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 0, 11, 17),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 0, 12, 11),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 0, 15, 13),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 0, 19, 15),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 0, 11, 14),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 0, 13, 12),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 0, 15, 16),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 0, 14, 11),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 0, 17, 15),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 0, 16, 16),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 0, 11, 20),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 0, 15, 11),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 0, 13, 13),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 17, 18, 19),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 17, 18, 19),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 17, 18, 19),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 17, 18, 19),
(25, 'DIPAK ', 'BAPU', 'MALI ', 17, 18, 19),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 17, 18, 19),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 17, 18, 19),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 17, 18, 19),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 17, 18, 19),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 17, 18, 19),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 17, 18, 19),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 17, 18, 19),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 17, 18, 19),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 17, 18, 19),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 17, 18, 19),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 17, 18, 19),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 17, 18, 19),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 17, 18, 19),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 17, 18, 19),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 17, 18, 19),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 17, 18, 19),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 17, 18, 19),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 17, 18, 19),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 17, 18, 19),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 17, 18, 19),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 17, 18, 19),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 17, 18, 19),
(48, 'SHUBHAM ', 'KISHOR', 'ARAGADE', 17, 18, 19),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 17, 18, 19),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 17, 18, 19),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 17, 18, 19),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 17, 18, 19),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 17, 18, 19),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 17, 18, 19),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 17, 18, 19),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 17, 18, 19),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 17, 18, 19),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 17, 18, 19),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 17, 18, 19),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 17, 18, 19),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 17, 18, 19),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 17, 18, 19);

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `downloads` int(11) NOT NULL,
  `dbname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `name`, `size`, `downloads`, `dbname`) VALUES
(1, '1st Sem Comp result.pdf', 98380, 5, '1st Sem Computer Result'),
(5, 'Engg Syllabus.pdf', 987743, 1, '2024 Batch Syllabus'),
(6, '2nd Sem Comp result.pdf', 107513, 0, '2nd Sem Computer Result');

-- --------------------------------------------------------

--
-- Table structure for table `nm`
--

CREATE TABLE `nm` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `2022-12-01` int(5) DEFAULT NULL,
  `2022-12-20` int(5) DEFAULT NULL,
  `2022-12-19` int(5) DEFAULT NULL,
  `2022-12-22` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nm`
--

INSERT INTO `nm` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `2022-12-01`, `2022-12-20`, `2022-12-19`, `2022-12-22`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 0, 0, 0, 1),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 1, 1, 1, 1),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 1, 1, 1, 1),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 1, 1, 1, 1),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 1, 1, 1, 1),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 1, 1, 1, 1),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 1, 1, 1, 1),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 1, 1, 1, 1),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 1, 1, 1, 1),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 1, 1, 1, 1),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 1, 1, 1, 1),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 1, 1, 1, 1),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 1, 0, 1, 1),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 1, 1, 1, 1),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 1, 1, 1, 1),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 1, 1, 1, 1),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 1, 1, 1, 1),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 1, 1, 1, 1),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 1, 1, 1, 1),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 1, 1, 0, 1),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 1, 1, 1, 1),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 1, 1, 1, 1),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 1, 1, 1, 1),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 1, 1, 1, 1),
(25, 'DIPAK ', 'BAPU', 'MALI ', 0, 1, 0, 1),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 1, 1, 1, 1),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 1, 1, 1, 1),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 1, 1, 1, 0),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 1, 1, 1, 1),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 0, 1, 1, 1),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 1, 1, 1, 1),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 1, 1, 1, 1),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 1, 1, 1, 1),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 1, 1, 1, 1),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 1, 1, 1, 1),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 1, 1, 1, 1),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 1, 1, 1, 1),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 1, 1, 1, 1),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 1, 1, 1, 1),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 1, 1, 1, 1),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 1, 1, 1, 1),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 1, 1, 1, 1),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 1, 1, 1, 1),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 1, 1, 1, 1),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 1, 1, 1, 1),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 1, 1, 1, 1),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 1, 1, 1, 1),
(48, 'SHUBHAM ', 'KISHOR', 'ARAGADE', 1, 1, 1, 0),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 1, 1, 1, 0),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 1, 1, 1, 0),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 1, 1, 1, 1),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 1, 1, 1, 1),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 1, 1, 1, 1),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 1, 1, 1, 1),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 1, 1, 1, 1),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 1, 1, 1, 0),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 1, 1, 1, 1),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 1, 1, 1, 1),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 1, 1, 1, 1),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 0, 1, 1, 1),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 1, 1, 1, 1),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nm_marks`
--

CREATE TABLE `nm_marks` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `ca1` int(5) DEFAULT NULL,
  `midsem` int(5) DEFAULT NULL,
  `ca2` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nm_marks`
--

INSERT INTO `nm_marks` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `ca1`, `midsem`, `ca2`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 18, 14, 19),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 15, 13, 17),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 16, 15, 13),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 13, 16, 15),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 14, 17, 19),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 17, 18, 12),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 7, 19, 14),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 15, 11, 16),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 5, 12, 15),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 16, 14, 13),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 12, 17, 12),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 15, 13, 19),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 14, 15, 14),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 1, 11, 12),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 6, 14, 11),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 13, 17, 15),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 15, 18, 16),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 14, 20, 20),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 12, 13, 15),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 16, 20, 20),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 17, 18, 19),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 17, 18, 19),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 17, 18, 19),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 17, 18, 19),
(25, 'DIPAK ', 'BAPU', 'MALI ', 17, 18, 19),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 17, 18, 19),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 17, 18, 19),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 17, 18, 19),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 17, 18, 19),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 17, 18, 19),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 17, 18, 19),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 17, 18, 19),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 17, 18, 19),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 17, 18, 19),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 17, 18, 19),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 17, 18, 19),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 17, 18, 19),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 17, 18, 19),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 17, 18, 19),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 17, 18, 19),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 17, 18, 19),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 17, 18, 19),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 17, 18, 19),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 17, 18, 19),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 17, 18, 19),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 17, 18, 19),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 17, 18, 19),
(48, 'SHUBHAM ', 'KISHOR', 'ARAGADE', 17, 18, 19),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 17, 18, 19),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 17, 18, 19),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 17, 18, 19),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 17, 18, 19),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 17, 18, 19),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 17, 18, 19),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 17, 18, 19),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 17, 18, 19),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 17, 18, 19),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 17, 18, 19),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 17, 18, 19),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 17, 18, 19),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 17, 18, 19),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 17, 18, 19);

-- --------------------------------------------------------

--
-- Table structure for table `present`
--

CREATE TABLE `present` (
  `Roll_no` int(15) NOT NULL,
  `12/12/2022` int(5) DEFAULT NULL,
  `13/12/2022` int(5) DEFAULT NULL,
  `14/12/2022` int(5) DEFAULT NULL,
  `16/12/2022` int(5) DEFAULT NULL,
  `2022-12-16` int(5) DEFAULT NULL,
  `2022-12-12` int(5) DEFAULT NULL,
  `2022-12-17` int(5) DEFAULT NULL,
  `2022-12-01` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `present`
--

INSERT INTO `present` (`Roll_no`, `12/12/2022`, `13/12/2022`, `14/12/2022`, `16/12/2022`, `2022-12-16`, `2022-12-12`, `2022-12-17`, `2022-12-01`) VALUES
(1, 1, 1, 1, 0, 1, 0, 1, 0),
(2, 1, 0, 1, 0, 1, 1, 1, 1),
(3, 0, 1, 1, 0, 1, 1, 1, 1),
(4, 1, 1, 1, 0, 1, 1, 1, 1),
(5, 1, 1, 1, 0, 1, 0, 1, 0),
(6, 1, 0, 1, 0, 1, 0, 1, 0),
(7, 0, 0, 1, 0, 1, 1, 1, 1),
(8, 1, 1, 1, 0, 1, 1, 1, 1),
(9, 1, 1, 1, 0, 1, 1, 1, 1),
(10, 1, 1, 1, 0, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `se`
--

CREATE TABLE `se` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `2022-12-19` int(5) DEFAULT NULL,
  `2022-12-20` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `se`
--

INSERT INTO `se` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `2022-12-19`, `2022-12-20`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 1, 1),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 1, 1),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 1, 1),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 1, 1),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 1, 1),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 1, 1),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 1, 1),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 1, 1),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 1, 1),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 1, 1),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 1, 1),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 1, 1),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 1, 1),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 0, 1),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 1, 1),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 1, 1),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 1, 1),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 1, 1),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 1, 1),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 1, 1),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 1, 1),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 1, 1),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 1, 1),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 1, 1),
(25, 'DIPAK ', 'BAPU', 'MALI ', 1, 1),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 0, 1),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 1, 1),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 0, 1),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 1, 1),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 0, 0),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 1, 1),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 1, 1),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 1, 1),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 1, 1),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 1, 0),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 1, 1),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 1, 1),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 1, 1),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 1, 1),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 1, 1),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 1, 1),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 1, 1),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 1, 1),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 1, 1),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 0, 0),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 1, 1),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 1, 1),
(48, 'SHUBHAM ', 'KISHOR', 'ARAGADE', 1, 1),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 1, 1),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 1, 1),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 1, 1),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 1, 0),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 1, 1),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 1, 1),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 1, 1),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 0, 1),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 1, 1),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 0, 1),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 1, 1),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 1, 0),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 1, 1),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `se_marks`
--

CREATE TABLE `se_marks` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `ca1` int(5) DEFAULT NULL,
  `midsem` int(5) DEFAULT NULL,
  `ca2` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `se_marks`
--

INSERT INTO `se_marks` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `ca1`, `midsem`, `ca2`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 16, 19, 14),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 17, 18, 15),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 19, 17, 16),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 15, 16, 17),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 13, 15, 18),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 19, 14, 19),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 15, 13, 12),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 17, 12, 11),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 18, 11, 14),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 16, 10, 15),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 15, 9, 13),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 17, 8, 18),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 19, 7, 16),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 18, 6, 17),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 16, 5, 19),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 17, 4, 12),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 15, 3, 15),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 20, 20, 20),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 18, 1, 13),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 20, 20, 20),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 17, 18, 19),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 17, 18, 19),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 17, 18, 19),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 17, 18, 19),
(25, 'DIPAK ', 'BAPU', 'MALI ', 17, 18, 19),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 17, 18, 19),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 17, 18, 19),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 17, 18, 19),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 17, 18, 19),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 17, 18, 19),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 17, 18, 19),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 17, 18, 19),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 17, 18, 19),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 17, 18, 19),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 17, 18, 19),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 17, 18, 19),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 17, 18, 19),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 17, 18, 19),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 17, 18, 19),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 17, 18, 19),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 17, 18, 19),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 17, 18, 19),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 17, 18, 19),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 17, 18, 19),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 17, 18, 19),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 17, 18, 19),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 17, 18, 19),
(48, 'SHUBHAM ', 'KISHOR', 'ARAGADE', 17, 18, 19),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 17, 18, 19),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 17, 18, 19),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 17, 18, 19),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 17, 18, 19),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 17, 18, 19),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 17, 18, 19),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 17, 18, 19),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 17, 18, 19),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 17, 18, 19),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 17, 18, 19),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 17, 18, 19),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 17, 18, 19),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 17, 18, 19),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 17, 18, 19);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Username` varchar(15) NOT NULL,
  `Password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Username`, `Password`) VALUES
('./TyComp24', '$tudent@2024'),
('*', '*');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `T_ID` int(5) NOT NULL,
  `Name` text NOT NULL,
  `Password` varchar(15) NOT NULL,
  `Subject` varchar(50) DEFAULT NULL,
  `ShortSub` varchar(20) DEFAULT NULL,
  `ShortMark` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`T_ID`, `Name`, `Password`, `Subject`, `ShortSub`, `ShortMark`) VALUES
(101, 'Bhushan Nandwalkar', 'Bhushan@2022', 'Database System', 'dbs', 'dbs_marks'),
(102, 'Khalid Alfatmi', 'Khalid@2022', 'Theory Of Computation', 'toc', 'toc_marks'),
(103, 'Vijaylaxmi Bittal', 'Vijaylaxmi@2022', 'Software Engineering', 'se', 'se_marks'),
(104, 'Chandu Koli', 'Chandu@2022', 'Numerical Methods', 'nm', 'nm_marks'),
(105, 'Sambhaji Pawar', 'Sambhaji@2022', 'Business Comunication', 'bc', 'bc_marks');

-- --------------------------------------------------------

--
-- Table structure for table `toc`
--

CREATE TABLE `toc` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `2022-12-20` int(5) DEFAULT NULL,
  `2022-12-19` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `toc`
--

INSERT INTO `toc` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `2022-12-20`, `2022-12-19`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 1, 1),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 1, 1),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 1, 1),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 1, 1),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 1, 1),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 1, 1),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 1, 1),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 1, 1),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 1, 1),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 1, 1),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 1, 1),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 1, 0),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 1, 1),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 1, 1),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 1, 1),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 1, 1),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 1, 1),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 1, 1),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 1, 1),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 1, 1),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 1, 1),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 1, 1),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 1, 1),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 1, 1),
(25, 'DIPAK ', 'BAPU', 'MALI ', 1, 0),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 1, 1),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 1, 1),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 1, 1),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 1, 1),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 1, 0),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 1, 1),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 1, 1),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 1, 1),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 1, 1),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 1, 1),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 1, 1),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 1, 1),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 1, 1),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 1, 1),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 1, 1),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 1, 1),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 1, 1),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 1, 1),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 1, 1),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 1, 1),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 1, 1),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 1, 1),
(48, 'SHUBHAM ', 'KISHOR', 'ARAGADE', 1, 1),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 1, 1),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 1, 1),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 1, 1),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 1, 1),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 1, 1),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 1, 1),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 1, 1),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 1, 1),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 1, 1),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 1, 1),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 1, 1),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 1, 1),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 1, 1),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `toc_marks`
--

CREATE TABLE `toc_marks` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `ca1` int(5) DEFAULT NULL,
  `midsem` int(5) DEFAULT NULL,
  `ca2` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `toc_marks`
--

INSERT INTO `toc_marks` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `ca1`, `midsem`, `ca2`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 15, 11, 17),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 20, 13, 18),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 24, 15, 15),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 15, 17, 19),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 19, 19, 12),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 12, 12, 14),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 18, 14, 15),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 14, 16, 13),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 13, 18, 12),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 13, 12, 9),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 17, 13, 10),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 13, 11, 14),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 16, 15, 7),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 18, 17, 15),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 19, 14, 13),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 15, 19, 12),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 14, 13, 14),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 12, 20, 20),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 16, 19, 11),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 20, 11, 13),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 17, 18, 19),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 17, 18, 19),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 17, 18, 19),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 17, 18, 19),
(25, 'DIPAK ', 'BAPU', 'MALI ', 17, 18, 19),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 17, 18, 19),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 17, 18, 19),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 17, 18, 19),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 17, 18, 19),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 17, 18, 19),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 17, 18, 19),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 17, 18, 19),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 17, 18, 19),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 17, 18, 19),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 17, 18, 19),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 17, 18, 19),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 17, 18, 19),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 17, 18, 19),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 17, 18, 19),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 17, 18, 19),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 17, 18, 19),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 17, 18, 19),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 17, 18, 19),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 17, 18, 19),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 17, 18, 19),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 17, 18, 19),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 17, 18, 19),
(48, 'SHUBHAM ', 'KISHOR', 'ARAGADE', 17, 18, 19),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 17, 18, 19),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 17, 18, 19),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 17, 18, 19),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 17, 18, 19),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 17, 18, 19),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 17, 18, 19),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 17, 18, 19),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 17, 18, 19),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 17, 18, 19),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 17, 18, 19),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 17, 18, 19),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 17, 18, 19),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 17, 18, 19),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 17, 18, 19);

-- --------------------------------------------------------

--
-- Table structure for table `ty_students`
--

CREATE TABLE `ty_students` (
  `Roll_No` int(3) NOT NULL,
  `F_Name` varchar(15) NOT NULL,
  `Mid_Name` varchar(15) NOT NULL,
  `L_Name` varchar(15) NOT NULL,
  `Password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ty_students`
--

INSERT INTO `ty_students` (`Roll_No`, `F_Name`, `Mid_Name`, `L_Name`, `Password`) VALUES
(1, 'KUNAL ', 'SANJAY', 'AHIRRAO ', 'Nmims%2021'),
(2, 'HEMSHRI ', 'KISHOR', 'AMRUTKAR ', 'Nmims%2021'),
(3, 'KALPESH ', 'KAILAS', 'BADGUJAR ', 'Nmims%2021'),
(4, 'RUSHIKESH ', 'JITENDRA', 'BADGUJAR ', 'Nmims%2021'),
(5, 'PRATHAM ', 'MANOJKUMAR', 'BHAGAT ', 'Nmims%2021'),
(6, 'PRATIK ', 'MANOJKUMAR', 'BHAGAT ', 'Nmims%2021'),
(7, 'SANKET ', 'PRAKASH', 'BORSE ', 'Nmims%2021'),
(8, 'TEJAS ', 'WALMIK', 'BORSE ', 'Nmims%2021'),
(9, 'VAISHNAVI ', 'RAJESH', 'CHAUDHARI ', 'Nmims%2021'),
(10, 'PURVA ', 'VIRENDRASINGH', 'CHAUHAN ', 'Nmims%2021'),
(11, 'NEHA ', 'BARKU', 'DESHMUKH ', 'Nmims%2021'),
(12, 'RUCHI ', 'MAHESH', ' DHAMECHA ', 'Nmims%2021'),
(13, 'JAYESH ', 'GOPINATH', 'GARUD ', 'Nmims%2021'),
(14, 'ANUSHKA ', 'PARAS', 'JAIN ', 'Nmims%2021'),
(15, 'MURTAZA ', 'JUZAR', 'JARIF ', 'Nmims%2021'),
(16, 'GAGAN ', 'MANISH', ' JARSODIWALA ', 'Nmims%2021'),
(17, 'CHETAN ', 'ASHOK', 'KACHHAVA ', 'Nmims%2021'),
(18, 'SHUBHAM ', 'KAILAS', 'KALSEKAR ', 'Nmims%2021'),
(19, 'DARSHANA ', 'NITIN', 'KARBHARI ', 'Nmims%2021'),
(20, 'PRATHAMESH ', 'VIJAY', 'KASAR ', 'Nmims%2021'),
(21, 'WAIDEHEE ', 'ARUN', 'KELE ', 'Nmims%2021'),
(22, 'PRITAM ', 'SANDIP', ' LOKHANDE ', 'Nmims%2021'),
(23, 'DEEP ', 'KISHOR', 'MAHAJAN ', 'Nmims%2021'),
(24, 'AADITYA ', 'SWAPNIL', 'MAHALE ', 'Nmims%2021'),
(25, 'DIPAK ', 'BAPU', 'MALI ', 'Nmims%2021'),
(26, 'SAKSHI ', 'MADHUKAR', 'MANDWEKAR ', 'Nmims%2021'),
(27, 'BHAVESH ', 'MAHADU', 'NIKAM ', 'Nmims%2021'),
(28, 'SAKSHI ', 'MANOJKUMAR', 'PAGARIYA ', 'Nmims%2021'),
(29, 'SAKSHI ', 'MANOJ', 'PANDE ', 'Nmims%2021'),
(30, 'HARSHAL ', 'RAVINDRA', 'PATIL ', 'Nmims%2021'),
(31, 'HARSHAL ', 'VINOD', 'PATIL ', 'Nmims%2021'),
(32, 'HINDRAJ ', 'MILIND', ' PATIL ', 'Nmims%2021'),
(33, 'KETAKI ', 'NITIN', 'PATIL ', 'Nmims%2021'),
(34, 'MANISH ', 'SANJAY', 'PATIL ', 'Nmims%2021'),
(35, 'MANSI ', 'JAGDISH', 'PATIL ', 'Nmims%2021'),
(36, 'NISHAD ', 'SANJAY', 'PATIL ', 'Nmims%2021'),
(37, 'UTKARSHA ', 'RAJENDRA', 'PATIL ', 'Nmims%2021'),
(38, 'VISHWAJIT', 'JITENDRA', 'PATIL', 'Nmims%2021'),
(39, 'YASH ', 'NANASAHEB', 'PATIL ', 'Nmims%2021'),
(40, 'SAKSHI', 'SANJAY', ' PINGALE', 'Nmims%2021'),
(41, 'ASHIYA ', 'ASHOKAN ', 'PUTHALONKUNNATH', 'Nmims%2021'),
(42, 'SAIFUDDIN ', 'KURESH', 'SAIFEE ', 'Nmims%2021'),
(43, 'NIKITA ', 'KAMALAKAR', 'SALI ', 'Nmims%2021'),
(44, 'SHRUSHTI ', 'PRADIPKUMAR', 'SALUNKE ', 'Nmims%2021'),
(45, 'NAYAN ', 'PRAKASH', 'SAYAJI ', 'Nmims%2021'),
(46, 'CHAITANYA ', 'SANJAY', 'SHARMA ', 'Nmims%2021'),
(47, 'PIYUSH ', 'MAHESH', 'SHARMA ', 'Nmims%2021'),
(48, 'SHUBHAM ', '', 'ARAGADE', 'Nmims%2021'),
(49, 'ISHA ', 'SANJAY', 'SONAWANE ', 'Nmims%2021'),
(50, 'RUSHIKESH ', 'JAGDISH', 'SONWANE ', 'Nmims%2021'),
(51, 'VAIBHAVI ', 'MANOJ', 'SURYAWANSHI ', 'Nmims%2021'),
(52, 'SARVAGYA ', 'SUMANSAURABH', ' VARMA ', 'Nmims%2021'),
(53, 'ASHWINI ', 'RAMESH', 'VIBHANDIK ', 'Nmims%2021'),
(54, 'SAMRUDDHI ', 'GANESH', 'WADEKAR ', 'Nmims%2021'),
(55, 'ISHA ', 'SANJAY', 'WAGH ', 'Nmims%2021'),
(56, 'HARSHAL ', 'RAJU', 'WAGHARE ', 'Nmims%2021'),
(57, 'PRANAV ', 'SANJAY', ' WANI ', 'Nmims%2021'),
(58, 'KRUTIKA ', 'DILIP', 'YEOLA ', 'Nmims%2021'),
(59, 'PRATIKSHA ', 'ARUN', ' YESHI ', 'Nmims%2021'),
(60, 'RUPESH', 'SADESING', 'CHAVAN', 'Nmims%2021'),
(61, 'MANASHRI', 'SATISH', 'PATIL ', 'Nmims%2021'),
(62, 'RAHUL', 'ANILKUMAR', 'RELAN', 'Nmims%2021');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD UNIQUE KEY `sno` (`sno`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `present`
--
ALTER TABLE `present`
  ADD PRIMARY KEY (`Roll_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `present`
--
ALTER TABLE `present`
  MODIFY `Roll_no` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
